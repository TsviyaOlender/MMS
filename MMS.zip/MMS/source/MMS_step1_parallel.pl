#!
#!/usr/local/bin/perl
##############################
use Config::Simple;
use File::Path qw(make_path remove_tree);
##############################################################

my($paramFile) = shift(@ARGV);

## read run params
read_params($paramFile);
## load modules
load_modules();
## prepare directory structures
make_folders($neworg);


$mainD = "/home/labs/olenderlab/lvzvia/WIS_exp/HORDE/parallel_MMS";
## definition of files
$outfile = "$mainD/$neworg/libs/all_symbols_12Oct15.txt";
$outLib = "$mainD/$neworg/libs/all_ORs_pep_12Oct15.fa";
$outLenSeq = "$mainD/$neworg/libs/all_ORs_SeqLen.txt";
$HoutLenSeq = "$mainD/$neworg/libs/Human_SeqLen.txt";
$NewOrgLenSeq ="$mainD/$neworg/libs/$neworg"."_SeqLen.txt";
$NewOrgGeneStatus = "$mainD/$neworg/libs/$neworg"."_geneStatus.txt";
$inputORs = "$mainD/$neworg/libs/$neworg"."_input.fa";
$classificationOrder = "$mainD/$neworg/libs/$neworg"."_classification_order.txt";
#### Handle the new organism
#######################################################
# copy new organism lib to its place
system("cp $neworgLib $inputORs");

# for the new organism, create a file with 
# the gene status=> pseudo/intact
check_gene_status("$inputORs",$NewOrgGeneStatus);
# count sequence len, and make a file, except human
create_seq_len($NewOrgLenSeq,$inputORs);
# format to blast
system("formatdb -i $inputORs");

#geneOrder file
if($geneOrder == 0){
	system("grep \'>\' $inputORs > header.txt");
	open(OUT,">$classificationOrder")|| warn "can not save to file with classification order\n";
	open(IN,"header.txt")||warn "a problem in creating file with order of classification\n";
	while($line = <IN>){
		chomp($line);
		($name)=$line =~/>(.+)/;
		$name =~s/ //g;
		print OUT "$name\n";
	}
	close(OUT);
}

#human lib
#########################################################
# count sequence len for human
create_seq_len($HoutLenSeq,$HLib);
# format to blast
system("formatdb -i $HLib");

### other organism
#######################################################################
open(IN,"$repertoires")|| warn "can not locate file with libraries names\n";
my(@files) = <IN>;
chomp(@files);
close(IN);
# make all ORs library, except human
open(OUT,">$outLib")|| warn "can not locate outfile\n";
foreach $file (@files){
		open(FSEQ,"$file")|| warn "can not find the file $file\n";
		while($line = <FSEQ>){
			print OUT "$line";
		}
		close(FSEQ);

}
close(OUT);
# count sequence len for all organism
create_seq_len($outLenSeq,$outLib);
# format to blast
system("formatdb -i $outLib");

# blast human vs organism
$orgVsHuman= $neworg."_vs_human.txt";
$HumanVsOrg = "human_vs_".$neworg.".txt";
$orgVsAll=$neworg."_vs_all.txt";
$AllVsOrg="all_vs_".$neworg.".txt";
$self = $neworg."_vs_".$neworg.".txt";
#vs. human
@blast[0] = "blastall -p blastp -d $HLib -i $inputORs -v 20 -b 20 -F F -m 8 -o $neworg/blast/$orgVsHuman";
@blast[1] = "blastall -p blastp -d $inputORs -i $HLib -v 20 -b 20 -F F -m 8 -o $neworg/blast/$HumanVsOrg";
# vs. all
@blast[2] = "blastall -p blastp -d $outLib -i $inputORs -v 20 -b 20 -F F -m 8 -o $neworg/blast/$orgVsAll";
@blast[3] = "blastall -p blastp -d $inputORs -i $outLib -v 20 -b 20 -F F -m 8 -o $neworg/blast/$AllVsOrg";
# self
@blast[4] = "blastall -p blastp -d $inputORs -i $inputORs -v 20 -b 20 -F F -m 8 -o $neworg/blast/$self";

print "$blast1\n$blast2\n$blast3\n$blast4\n$blast5\n";
$i=0;
foreach $query (@blast){
  system("bsub -q new-short -e err.$i.txt -o log.$i.txt $query");
    $i++;
}


####################################################################################
sub load_modules{
  do ('/apps/RH7U2/Modules/default/init/perl.pm');
  module('load ncbi-blast+/2.5.0');
  module('load blast/2.2.26');

   return();
}
####################################################################################
sub make_folders{
  my($neworg)=@_;
  make_path("$neworg");
  make_path("$neworg/libs");
  make_path("$neworg/blast");
 return();
}
####################################################################################
sub create_seq_len{
	my($outLenSeq,$outLib)=@_;
	print "$outLenSeq,$outLib\n";
	# count sequence len, and make a file
	open(IN,"$outLib")|| warn "can not read from library $outLib\n";
	open(OUT,">$outLenSeq")|| warn "can not write to seq len file\n";
	$line = <IN>;
	chomp($line);
	$line =~s/>//;
	$symbol = $line;
	$seqL=0;

	while($line = <IN>){
			if($line =~/>/){
					print OUT "$symbol\t$seqL\n";
					chomp($line);
					$line =~s/>//;
					$symbol = $line;
					$seqL=0;
					
			}else{
					chomp($line);
					$seqL=$seqL+length($line);
			}
	}
	print OUT "$symbol\t$seqL\n";
	close(IN);
	close(OUT);
	return();
}

####################################################################################
sub read_params{
  my($param_file) = @_;

  $cfg = new Config::Simple("$param_file");
  # general files, not species dependent
  $HLib = $cfg->param("params.humanLib");
  $repertoires = $cfg->param("params.NohumanOrganismFileName");

  # organism parameters and files
  $neworg = $cfg->param("setup_run.organism");
  $neworgLib = $cfg->param("setup_run.organismORlib");# this comes with full path
  $geneOrder = $cfg->param("setup_run.geneOrder");# order of classification.
  # this can be 0, or 1.
  # if 0 => order will be generated here, otherwise=> supplied by user.


   return();
}
####################################################################################
sub check_gene_status{
	my($file,$outfile)=@_;
	
	open(LIB,"$file") || die "can not read from $file\n";
	open(OUT,">$outfile") || die "can not write to $outfile\n";
	$name = 0;
	while($line = <LIB>){
	  chomp($line);
	  if($line =~/^>/){
		# check sequence status
		if($name =~/[A-Z]/i){#the condition is for the first time
			($seqL,$fs,$ORF,$pseudo)=count_fs($seq);
			print OUT "$name\t$seqL\t$fs\t$ORF\t$pseudo\n";
		}
		($name) = $line =~/>(.+)/;
		$seq = '';
	  }else{
		$seq .= $line;
	  }
	}
	# check status of last dequence
	($seqL,$fs,$ORF,$pseudo)=count_fs($seq);
	print OUT "$name\t$seqL\t$fs\t$ORF\t$pseudo\n";
	close(LIB);
	close(OUT);
	
	return();
}
sub count_fs{
	my($seq) = @_;
	
	$fs = 0;
	$seqL = length($seq);
	if(($seq =~/^M/) ){
		$ORF=1;
		#chop($seq);
	}else{
		$ORF = 0;
	}
	while($seq){
		$AA = chop($seq);
		if(($AA eq '\\') or($AA eq '/') or ($AA eq '*')){
			$fs++;
		}
	}

	if(($seqL > 280) and ($fs == 0) and ($ORF==1)){
		$pseudo=0;

	}else{
		$pseudo = 1;
	}


	return($seqL,$fs,$ORF,$pseudo);

}