# the script assin symbols based on MMS comparison
my($organism) = @ARGV;
$mainDir = "/home/labs/olenderlab/lvzvia/WIS_exp/HORDE/parallel_MMS";
# defining all files that are required for the run
files_for_the_run();

#####################################################
# step1: preparation.
# coding of subfam and clade letters as numbers. 
# this is important because perl doesn't work well with characters.
# e.g. AB cmp B AB is higher
%subfamLetters = load_letters($subfamLetters);
%cladeLetters = load_letters($cladeLetters);
# Letters to numbers
%subfamLetters2num=load_letters_to_num($subfamLetters);
%cladeLetters2num= load_letters_to_num($cladeLetters);
#####################################################
#####################################################
# step 2
# upload and populate exsisting nomenclature
load_nomeclature(\%subfamLetters,\%cladeLetters);
load_self_classification();# populates %self
#####################################################
# step 3
# upload gene status (pseudo,intact)
open(IN,"$geneStatus")|| die "can not locate $geneStatus\n";
while($line = <IN>){
	chomp($line);
	my($candidate,$geneLen,$fd,$Met,$pseudo)= split(/\t/,$line);
	$candidates{$candidate}{pseudo}=$pseudo;
	$candidates{$candidate}{nomec}=0;
}
close(IN);
#####################################################
# step4- load preclassification
# loads into memory the MMS step for each gene, as was determined in the previous step of MMS
# the data structure @suggestedNomec is arranged in the same order as the classification order
# as in the previous step.
# I also keep a hash with the index of each gene 
(@sugestedNomec)=load_classification($sugestedNomec);

#####################################################
# step5- assign symbols
# intact genes first.
# MuBeH, Second Best
assign_steps_1_2();#BeH, second-best
# new subfam mem
assign_new_subfam_mem();# includes also self comparison. "for the like".
#new fam
assign_new_subfam();# includes also self comparison, for new subfam member based on self

open(OUT,">$symbolsFile")|| warn "can not write to $symbolsFile\n";
$i=0;
foreach $item (0..$#sugestedNomec){
	$candidate = $sugestedNomec[$i]{gene};
	print OUT "$candidate,$candidates{$candidate}{pseudo},$candidates{$candidate}{symbol},$candidates{$candidate}{BeH},$sugestedNomec[$i]{MMSstep},$sugestedNomec[$i]{suggested}\n";
	$i++;
}
close(OUT);

#####################################################
#####################################################
sub files_for_the_run{
	# files for the run:
	$subfamLetters = "$mainDir/source/"."subfamLetters.txt";
	$cladeLetters = "$mainDir/source/"."cladeLetters.txt";
	$humanData= "$mainDir/"."$organism"."/libs/Human_SeqLen.txt";
	$allOrgData= "$mainDir/"."$organism"."/libs/all_ORs_SeqLen.txt";
	$geneStatus = "$mainDir/"."$organism"."/libs/"."$organism"."_geneStatus.txt";
	#######
	# classification files
	$sugestedNomec= "$mainDir/"."$organism/"."$organism"."_MMS_final.txt";
	$selfClassificationFile="$mainDir/"."$organism/"."$organism"."_MMS_self_final.txt";
	$classificationOrder = "$mainDir/"."$organism/"."/libs/"."$organism"."_classification_order.txt";
	###
	# final file
	$symbolsFile = "$mainDir/"."$organism/"."$organism"."_suggestedSymbols.txt";
	return();
}
sub load_letters{
	my($infile)=@_;
	my(%lettersToNum)=();
	open(IN,"$infile")|| warn "no $infile\n";
	$i=1;
	while($letter = <IN>){
		chomp($letter);
		$lettersToNum{$letter}=$i;
		$i++;
	}
	
	
	close(IN);
	return(%lettersToNum);
}
sub load_letters_to_num{
	my($infile)=@_;
	my(%NumToLetters)=();
	open(IN,"$infile")|| die "no $infile\n";
	$i=1;
	while($letter = <IN>){
		chomp($letter);
		$NumToLetters{$i}=$letter;
		$i++;
	}
	
	
	close(IN);
	return(%NumToLetters);
}
sub load_nomeclature{
# read into the program the current exsisting symbols.
# keeps in the memory the last (higher) number/member of
# clade, family member, subfamily
# the data structures are:
##########################
# $subfamily{$fam} with the higher subfamily letter, coded as number
# $subfam_number{$subfam_j} with the higher subfamily member number.
# $subfam_j is for example 10A
# $clade{$clade_j} with the higher clade member letter, coded as number.
# $clade_j is for example 10JC
	my($refSubFamLet,$refCladeLet)= @_;
	my(%SubFamLet)=%{$refSubFamLet};
	my(%CladeLet)=%{$refCladeLet};

	#1) load human symbols
	%subfamily=();
	%subfam_number=();
	%clade = ();
	
	###
	@files = ($humanData,$allOrgData);# files were defined by files_for_the_run subroooutine
	$i=-1;
	foreach $file (@files){
		$i++;
		open(IN,"$file")|| warn "can not read from $file, subroutine upload_nomeclature\n";
		while($line = <IN>){
		  chomp($line);
		  ($name,@more) =split(/\t/,$line);
		  if($i==0){#human
			$symbol = uc($name);
		  }else{# non human. symbols come with organism name
			($symbol,$organism) = split(/\_/,$name);
			$symbol = uc($symbol);
		  }
		  if($symbol =~/\-ps$/i){# in mouse,rat pseudogene end with ps
			($newS,$temp) = split(/\-/,$symbol);
			$symbol = $newS;
			$symbol = uc($symbol);
		  }
		  if($symbol =~ /P$/){# get rid from the P, saved for pseudogenes
			chop($symbol);
		  }
		  ($fam,$subfam,$member,$clade) = $symbol =~/OR(\d+)([A-Z]+)(\d+)([A-Z]*)/i;
		  $subfam_j = "$fam$subfam";
		   $clade_j ="$fam$subfam$member";
		
		
		   # I keep three data structures:
		   # 1. subfam_number- with the last subfamily member number= to assign new subfamily members
		   # 2. clades
		   # 3. subfamily,
		   if($SubFamLet{$subfam} > $subfamily{$fam}){# comparing subfam letters
			 $subfamily{$fam} =$SubFamLet{$subfam};
		   }	
		   if($member > $subfam_number{$subfam_j}){# comparing number of member within subfam
			 $subfam_number{$subfam_j}=$member;
		   }
		   if($CladeLet{$clade} > $clade{$clade_j}){
			$clade{$clade_j}=$CladeLet{$clade};
		   }
		   
		   
		}
		close(IN);

	}
	
	return();
}
sub load_self_classification{
	%self = ();
	open(IN,"$selfClassificationFile")|| die "can not read from self classification file\n";
	$line = <IN>;
	while($line = <IN>){
		chomp($line);
		my($gene,$myhit,$id,$alignF,$classification)=split(/\t/,$line);
		$self{$gene}{hit}=$myhit;
		$self{$gene}{id}=$id;
		$self{$gene}{alignF}=$alignF;
		$self{$gene}{classification}=$classification;
	}
	
	close(IN);
	
	return();
}
sub load_classification{
	my($file) = @_;
	# load classification order
	open(IN,"$classificationOrder")|| die "can not file the file with the classification order\n";
	@classificationOrder = <IN>;
	chomp(@classificationOrder);
	close(IN);
	$i=0;
	foreach $item (@classificationOrder){
		$classificationOrder{$item}=$i;
		$i++;
	}
	
	
	# the classification of the new repertoire is 
	# loaded into an array. The array is important to keep the order
	my @data = ();
	open(IN,"$file")||die "can not read from $file, subroutine load_classification\n";
	$line = <IN>;
	while($line = <IN>){
		chomp($line);
	#gene    MMSstep BestMatch       ID      %ofORLength     SuggestedClade
		my($gene,$MMSstep,$hit,$t,$t,$SuggestedClade,$method)=split(/\t/,$line);
		$index = $classificationOrder{$gene};
		$data[$index]{gene}=$gene; $data[$index]{MMSstep}=$MMSstep, $data[$index]{suggested}=$SuggestedClade;$data[$index]{hit}=$hit; 
	}
	close(IN);

	
	return(@data);
}
sub assign_steps_1_2{
	
	$i=0;
	foreach $item (0..$#sugestedNomec){
		$candidate = $sugestedNomec[$i]{gene};
		
		if($candidates{$candidate}{nomec}==0){
			if($sugestedNomec[$i]{MMSstep} =~ /MuBest_/){
				$suggestedClade = $sugestedNomec[$i]{suggested};
				$candidates{$candidate}{symbol} = "OR"."$suggestedClade";
				$candidates{$candidate}{nomec}=1;
				$candidates{$candidate}{BeH}=$sugestedNomec[$i]{hit};
			}elsif($sugestedNomec[$i]{MMSstep}=~/SecondBest_/){
			#cladeLetters
			#cladeLetters2num
				$suggestedClade = $sugestedNomec[$i]{suggested};
				$tentativeSymbol=get_symbol_clade($suggestedClade);
				$candidates{$candidate}{symbol}=$tentativeSymbol;
				$candidates{$candidate}{nomec}=1;
				$candidates{$candidate}{BeH}=$sugestedNomec[$i]{hit};
			}
		}
		$i++;
	}
	return();
}

sub assign_new_subfam_mem{

	$i=0;
	foreach $item (0..$#sugestedNomec){
		$candidate = $sugestedNomec[$i]{gene};
		$selfBeH = $self{$candidate}{hit};
		$type = $self{$candidate}{classification};
		
		if(($candidates{$candidate}{nomec}==0) and ($type eq'SecondBest') and ($candidates{$selfBeH}{nomec}==1)){
			($suggestedClade) = $candidates{$selfBeH}{symbol} =~/OR(.+)/;
			$tentativeSymbol=get_symbol_clade($suggestedClade);
			$candidates{$candidate}{symbol}=$tentativeSymbol;
			$candidates{$candidate}{nomec}=1;
			$candidates{$candidate}{BeH}=$sugestedNomec[$i]{hit};
			
		}elsif(($candidates{$candidate}{nomec}==0) and ($sugestedNomec[$i]{MMSstep} =~ "newSubfam_mem")){
				$suggestedClade = $sugestedNomec[$i]{suggested};
				my($subfam)=$suggestedClade=~/(\d+[A-Z]+)/;
				$current_last_member=$subfam_number{$subfam};
				$new_member = $current_last_member+1;
				$candidates{$candidate}{symbol} = "OR"."$subfam"."$new_member";
				$candidates{$candidate}{nomec}=1;
				$subfam_number{$subfam}=$new_member;
				$candidates{$candidate}{BeH}=$sugestedNomec[$i]{hit};
				
		}
		
		
		$i++;
	}
	return();
}

sub assign_new_subfam{
	$i=0;
	foreach $item (0..$#sugestedNomec){
		$candidate = $sugestedNomec[$i]{gene};
		$selfBeH = $self{$candidate}{hit};
		$type = $self{$candidate}{classification};
		#check self first
		if(($candidates{$candidate}{nomec}==0) and ($type eq'SecondBest') and ($candidates{$selfBeH}{nomec}==1)){
			($suggestedClade) = $candidates{$selfBeH}{symbol} =~/OR(.+)/;
			$tentativeSymbol=get_symbol_clade($suggestedClade);
			$candidates{$candidate}{symbol}=$tentativeSymbol;
			$candidates{$candidate}{nomec}=1;
			$candidates{$candidate}{BeH}=$self{$candidate}{hit};
			
		}elsif(($candidates{$candidate}{nomec}==0) and ($type eq'NewSubfam_self') and ($candidates{$selfBeH}{nomec}==1)){
			my($subfam) = $candidates{$selfBeH}{symbol} =~/OR(\d+[A-Z]+)/;
			$current_last_member=$subfam_number{$subfam};
			$new_member = $current_last_member+1;
			$candidates{$candidate}{symbol} = "OR"."$subfam"."$new_member";
			$candidates{$candidate}{nomec}=1;
			$subfam_number{$subfam}=$new_member;
			$candidates{$candidate}{BeH}=$self{$candidate}{hit};
			
		}elsif(($sugestedNomec[$i]{MMSstep} =~/new_subfam_/) and ($candidates{$candidate}{nomec}==0)){
				$suggestedClade = $sugestedNomec[$i]{suggested};
				my($fam)=$suggestedClade=~/(\d+)[A-Z]+\d+/;
				$current_last_subfam=$subfamily{$fam};
				$new_subfam_number = $current_last_subfam+1;
				# number to letter
				$new_subfam_letter = $subfamLetters2num{$new_subfam_number};
				
				$subfam_j = "$fam"."$new_subfam_letter";
				$candidates{$candidate}{symbol} = "OR"."$subfam_j"."1";
				$candidates{$candidate}{nomec}=1;
				$subfamily{$subfam}=$new_subfam_number;
				$subfam_number{$subfam_j}=1;
				$candidates{$candidate}{BeH}=$sugestedNomec[$i]{hit};

		}
		$i++;
	}
	return();
}
sub get_symbol_clade{
	my($testedClade)=@_;
	my($mySymbol)='';
	if($clade{$testedClade} > 0){# for cases where we already have 1D5B,1D5C
		$newCladeNum = $clade{$testedClade}+1;
		$mySymbol = "OR"."$testedClade"."$cladeLetters2num{$newCladeNum}";
		# we keep the update in the clade number
		$clade{$testedClade}=$newCladeNum;
	}else{# this is the first "like" symbol
		$mySymbol = "OR"."$suggestedClade"."B";
		$clade{$suggestedClade}=2;
	}

	return($mySymbol);
}