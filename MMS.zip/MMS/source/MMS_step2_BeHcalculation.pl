#!
my($organism) = @ARGV;
#######################################
# classification cutoffs
$beH_cutoff=80;
$align_frac_cutoff = 0.8;
####################################################
# input files
$FileDir = $organism."/libs/";
$humanDetails = $FileDir."Human_SeqLen.txt";
$allDetails = $FileDir."all_ORs_SeqLen.txt";
$selfDetails = $FileDir.$organism."_SeqLen.txt";
$classificationOrder = $FileDir.$organism."_classification_order.txt";
#####################################################
# output files
$MMM_matrix_results_maxAv= $organism."/".$organism."_MMS_maxAv.txt";
$MMM_matrix_results_maxShort=$organism."/".$organism."_MMS_maxShort.txt";
# final output
$MMM_matrix_results_final=$organism."/".$organism."_MMS_final.txt";
$MMM_matrix_self_final=$organism."/".$organism."_MMS_self_final.txt";
# load to memory the gene names, and the gene length
# initiates MMM hash
%mms_maxAv=();
%mms_maxShort=();
get_OR_details($humanDetails,"human");
get_OR_details($allDetails,"all");
get_OR_details($selfDetails,"$organism");
# load classification order
open(IN,"$classificationOrder")|| die "can not file the file with the classification order\n";
@classificationOrder = <IN>;
chomp(@classificationOrder);
close(IN);

############################################################
# parse blast reports, determine BeH foreach species
# BeH determines the best hit match among 2 species
# BeH keys look like:$BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_id}
#		$BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_gene}
#		$BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_id};
#		$BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_gene}
# thus: for every BeH we keep the gene name and the normalized ID
####################################################################
%BeH=();
$FileDir = $organism."/blast/";
@sp=('human','all');
$sp1=$organism;
foreach $sp (@sp){
	$sp2=$sp;
	$blast1 = $FileDir."$sp1"."_vs_"."$sp2".".txt";
	load_run($blast1,$sp1,$sp2);
	#
	$blast1 = $FileDir."$sp2"."_vs_"."$sp1".".txt";
	load_run($blast1,$sp2,$sp1);
}

$sp2 = $organism;
$blast1 = $FileDir."$sp1"."_vs_"."$sp2".".txt";
load_run($blast1,$sp1,$sp2);

##################################################
# START classification
##################################################
# 1. find gene with mutual BeH
$sp2='human';
assign_mutual($sp1,$sp2);
$sp2='all';
assign_mutual($sp1,$sp2);
$sp2='human';
find_best_column($sp1,$sp2);
$sp2='all';
find_best_column($sp1,$sp2);
#
# now we search with the sort method
$sp2='human';
assign_mutual_and_best_short($sp1,$sp2);
$sp2='all';
assign_mutual_and_best_short($sp1,$sp2);


$sp2='human';
find_fam_subfam($sp1,$sp2);
$sp2='all';
find_fam_subfam($sp1,$sp2);
###
# if no subfamily was found, find family
$sp2='human';
find_fam($sp1,$sp2);
$sp2='all';
find_fam($sp1,$sp2);

#self comparison
# this will be saved in a sepearte file
$sp2=$organism;
%self = ();
find_self($sp1,$sp2);

##################################################
# save results
##################################################
save_results($MMM_matrix_results_maxAv,\%mms_maxAv);
save_results($MMM_matrix_results_maxShort,\%mms_maxShort);
###################################################
# save final, merge the two methods into 1
open(OUT,">$MMM_matrix_results_final")||die "can not write to finale file\n";
print OUT "gene\tMMSstep\tBestMatch\tID\t%ofORLength\tSuggestedClade\tmethod\n";
$geneDecision = ();
$MutBeFound = ();
# zero arrays
foreach $gene (@classificationOrder){
	$geneDecision{$gene}=0;
	$MutBeFound{$mms_maxAv{$gene}{clade}}=0;
}
#MuBeH, maxAv
foreach $gene (@classificationOrder){
	if(($mms_maxAv{$gene}{step} =~ /MuBest_/) and ($geneDecision{$gene}==0) and($MutBeFound{$mms_maxAv{$gene}{clade}} ==0)){
		print OUT "$gene\t$mms_maxAv{$gene}{step}\t$mms_maxAv{$gene}{gene}\t$mms_maxAv{$gene}{id}\t$mms_maxAv{$gene}{alignFrac}\t$mms_maxAv{$gene}{clade}\tmaxAv\n";
		$geneDecision{$gene}=1;
		$MutBeFound{$mms_maxAv{$gene}{clade}}=1;
		
	}elsif(($mms_maxAv{$gene}{step} =~ /MuBest_/) and ($geneDecision{$gene}==0) and($MutBeFound{$mms_maxAv{$gene}{clade}} ==1)){
				$mms_maxAv{$gene}{step} =~s/MuBest_/SecondBest_/;# this can happened if two genes show MuBest to two different genes
				# from the same clade. e.g MuBest_all to OR2Z2_dog and MuBest_all to Or2z2_mouse
				print OUT "$gene\t$mms_maxAv{$gene}{step}\t$mms_maxAv{$gene}{gene}\t$mms_maxAv{$gene}{id}\t$mms_maxAv{$gene}{alignFrac}\t$mms_maxAv{$gene}{clade}\tmaxAv_m\n";
				$geneDecision{$gene}=1;

	}
}
# MuBeH short
foreach $gene (@classificationOrder){
	if(($mms_maxShort{$gene}{step} =~ /MuBest_/) and ($geneDecision{$gene}==0) and($MutBeFound{$mms_maxShort{$gene}{clade}} ==0)){
		print OUT "$gene\t$mms_maxShort{$gene}{step}\t$mms_maxShort{$gene}{gene}\t$mms_maxShort{$gene}{id}\t$mms_maxShort{$gene}{alignFrac}\t$mms_maxShort{$gene}{clade}\tmaxShort\n";
		$geneDecision{$gene}=1;
		$MutBeFound{$mms_maxShort{$gene}{clade}}=1;
	}elsif(($mms_maxShort{$gene}{step} =~ /MuBest_/) and ($geneDecision{$gene}==0) and($MutBeFound{$mms_maxShort{$gene}{clade}} ==1)){
				$mms_maxShort{$gene}{step} =~s/MuBest_/SecondBest_/;
				print OUT "$gene\t$mms_maxShort{$gene}{step}\t$mms_maxShort{$gene}{gene}\t$mms_maxShort{$gene}{id}\t$mms_maxShort{$gene}{alignFrac}\t$mms_maxShort{$gene}{clade}\tmaxShort_m\n";
				$geneDecision{$gene}=1;
	}
}
#SecondBest
foreach $gene (@classificationOrder){
	if(($mms_maxAv{$gene}{step} =~ /SecondBest_/) and ($geneDecision{$gene}==0)){
		print OUT "$gene\t$mms_maxAv{$gene}{step}\t$mms_maxAv{$gene}{gene}\t$mms_maxAv{$gene}{id}\t$mms_maxAv{$gene}{alignFrac}\t$mms_maxAv{$gene}{clade}\tmaxAv\n";
		$geneDecision{$gene}=1;
	}
}
foreach $gene (@classificationOrder){
	if(($mms_maxShort{$gene}{step} =~ /SecondBest_/) and ($geneDecision{$gene}==0)){
		print OUT "$gene\t$mms_maxShort{$gene}{step}\t$mms_maxShort{$gene}{gene}\t$mms_maxShort{$gene}{id}\t$mms_maxShort{$gene}{alignFrac}\t$mms_maxShort{$gene}{clade}\tmaxShort\n";
		$geneDecision{$gene}=1;
	}
}
# everything that was left
foreach $gene (@classificationOrder){
	if($geneDecision{$gene}==0){
		print OUT "$gene\t$mms_maxAv{$gene}{step}\t$mms_maxAv{$gene}{gene}\t$mms_maxAv{$gene}{id}\t$mms_maxAv{$gene}{alignFrac}\t$mms_maxAv{$gene}{clade}\tNA\n";
			$geneDecision{$gene}=1;
	}
}

close(OUT);

open(OUT,">$MMM_matrix_self_final")|| warn "can not write to file $MMM_matrix_self_final\n";
# save self
foreach $gene (@classificationOrder){
	if($self{$gene}{score}==1){
		print OUT "$gene\t$self{$gene}{gene}\t$self{$gene}{alignFrac}\t$self{$gene}{id}\t$self{$gene}{step}\n";
	}
}
close(OUT);

#############################################################################################################
#############################################################################################################
#############################################################################################################
sub assign_mutual{
	my($sp1,$sp2)=@_;
	foreach $gene (@classificationOrder){
		#mutual best with average normalization
		my $BeH_gene=$BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_gene};

		#now we ask who is the BeH of BeH_gene
		if(($gene eq $BeH{$sp2}{$sp1}{$BeH_gene}{maxAv}{BeH_gene})and ($BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_id} >= $beH_cutoff) and ($BeH{$sp1}{$sp2}{$gene}{maxAv}{alignFrac} > $align_frac_cutoff)){

			# we found it
			if($mms_maxAv{$gene}{score}== 0){
				$mms_maxAv{$gene}{score}=1;# if score ==1, the algorithm will not search any more
				$mms_maxAv{$gene}{step}="MuBest_".$sp2;
				$mms_maxAv{$gene}{gene}=$BeH_gene;
				$mms_maxAv{$gene}{id}=$BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_id};
				$mms_maxAv{$gene}{alignFrac}=$BeH{$sp1}{$sp2}{$gene}{maxAv}{alignFrac};
				$mms_maxAv{$gene}{clade}=uc($genes{$sp2}{$BeH_gene}{clade});
				
			}
		
		}	
	
	}
	return();
}
#############################################################################################################
sub find_best_column{
	my($sp1,$sp2) = @_;
	foreach $gene (@classificationOrder){
		if($mms_maxAv{$gene}{score}== 0){
			if(($BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_id} >= $beH_cutoff)and ($BeH{$sp1}{$sp2}{$gene}{maxAv}{alignFrac} > $align_frac_cutoff)){
				#second best
				$BeH_gene=$BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_gene};
				$mms_maxAv{$gene}{score}=1;# if score ==1, the algorithm will not search any more
				$mms_maxAv{$gene}{step}="SecondBest_".$sp2;
				$mms_maxAv{$gene}{gene}=$BeH_gene;
				$mms_maxAv{$gene}{id}=$BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_id};
				$mms_maxAv{$gene}{alignFrac}=$BeH{$sp1}{$sp2}{$gene}{maxAv}{alignFrac};
				$mms_maxAv{$gene}{clade}=uc($genes{$sp2}{$BeH_gene}{clade});
			}
		}

	
	}


	return();
}
#############################################################################################################
sub assign_mutual_and_best_short{
	my($sp1,$sp2)=@_;
	foreach $gene (@classificationOrder){
		my $BeH_gene=$BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_gene};
		#mutual best with shortest normalization
		if(($gene eq $BeH{$sp2}{$sp1}{$BeH_gene}{maxShort}{BeH_gene}) and ($BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_id} >= $beH_cutoff)and ($BeH{$sp1}{$sp2}{$gene}{maxShort}{alignFrac_short} > $align_frac_cutoff)){
	
			# we found it
			if($mms_maxShort{$gene}{score}== 0){
				$mms_maxShort{$gene}{score}=1;
				$mms_maxShort{$gene}{step}="MuBest_".$sp2;
				$mms_maxShort{$gene}{gene}=$BeH_gene;
				$mms_maxShort{$gene}{id}=$BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_id};
				$mms_maxShort{$gene}{alignFrac}=$BeH{$sp1}{$sp2}{$gene}{maxShort}{alignFrac};
				$mms_maxShort{$gene}{clade}=uc($genes{$sp2}{$BeH_gene}{clade});
			}
			
		}
	}
	foreach $gene (@classificationOrder){
		if($mms_maxShort{$gene}{score}== 0){

			if(($BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_id} >= $beH_cutoff)and ($BeH{$sp1}{$sp2}{$gene}{maxShort}{alignFrac_short} > $align_frac_cutoff)){	
				$BeH_gene=$BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_gene};
				$mms_maxShort{$gene}{score}=1;
				$mms_maxShort{$gene}{step}="SecondBest_".$sp2;
				$mms_maxShort{$gene}{gene}=$BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_gene};
				$mms_maxShort{$gene}{id}=$BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_id};
				$mms_maxShort{$gene}{alignFrac}=$BeH{$sp1}{$sp2}{$gene}{maxShort}{alignFrac};
				$mms_maxShort{$gene}{clade}=uc($genes{$sp2}{$BeH_gene}{clade});
			}
		}
	
	}
	return();
}
#############################################################################################################
sub find_fam_subfam{
	my($sp1,$sp2) = @_;
	foreach $gene (@classificationOrder){
		if($mms_maxAv{$gene}{score}== 0){
			$alignAA = $BeH{$sp1}{$sp2}{$gene}{maxShort}{alignFrac}*$genes{$sp1}{$gene}{ORlen};
			$BeH_gene=$BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_gene};
			#I am looking for alignment with more than 100 aa, with %id > 60%
			if(($BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_id} >=60) and ($alignAA >=100)){
				# this is not a mistake. We normalize to the gene length and save in the averaged
				# for future gene symbol assignment
				$mms_maxAv{$gene}{score}=1;# if score ==1, the algorithm will not search any more
				$mms_maxAv{$gene}{step}="newSubfam_mem_".$sp2;
				$mms_maxAv{$gene}{gene}=$BeH_gene;
				$mms_maxAv{$gene}{alignFrac}=$BeH{$sp1}{$sp2}{$gene}{maxShort}{alignFrac};
				$mms_maxAv{$gene}{id}=$BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_id};
				$mms_maxAv{$gene}{clade}=uc($genes{$sp2}{$BeH_gene}{clade});
			}
		}
	}	
	return();
}
#############################################################################################################
sub find_fam{
	my($sp1,$sp2) = @_;
	foreach $gene (@classificationOrder){
		if($mms_maxAv{$gene}{score}== 0){
			$alignAA = $BeH{$sp1}{$sp2}{$gene}{maxShort}{alignFrac}*$genes{$sp1}{$gene}{ORlen};
			$BeH_gene=$BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_gene};
			#I am looking for alignment with more than 100 aa, with %id > 60%
			if(($BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_id} >40) and ($alignAA >=100)){
				# this is not a mistake. We normalize to the gene length and save in the averaged
				# for future gene symbol assignment
				$mms_maxAv{$gene}{score}=1;# if score ==1, the algorithm will not search any more
				$mms_maxAv{$gene}{step}="new_subfam_".$sp2;
				$mms_maxAv{$gene}{gene}=$BeH_gene;
				$mms_maxAv{$gene}{alignFrac}=$BeH{$sp1}{$sp2}{$gene}{maxShort}{alignFrac};
				$mms_maxAv{$gene}{id}=$BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_id};
				$mms_maxAv{$gene}{clade}=uc($genes{$sp2}{$BeH_gene}{clade});
			}
		}
	}	
	return();
}

#############################################################################################################
sub get_OR_details{
	my($inFile,$org)= @_;
    open(IN,"$inFile")|| warn "can not locate $inFile, organism =$org\n";
  while($line = <IN>){
    chomp($line);
    ($name,$ORlen) = split(/\t/,$line);
	if(($org eq 'human') or ($org eq $organism)){# note- $organism is a global variable, while $org is private
	# if $org eq $organism means that we ask if we work on the classified organism
		$symbol = $name;
	    $organism1=$org;
	}elsif($org eq 'all'){
		($symbol,$organism1) =split(/\_/,$name);
	}
    ($clade) = get_clade($symbol);
    $genes{$org}{$name}{symbol}=$symbol;
    $genes{$org}{$name}{organism}=$organism1;
    $genes{$org}{$name}{clade}=$clade;
    $genes{$org}{$name}{ORlen}=$ORlen;
	# initiate MMS hash
	if($org eq $organism){
		$mms_maxAv{$name}{score}= 0;
		$mms_maxShort{$name}{score}= 0;
	}
  }
  close(IN);
  return();
}
#############################################################################################################
sub get_clade{
  my($input) = @_;
  my($clade) = $symbol =~/or(\d+[a-z]+\d+)/i;
 return($clade);
}
#############################################################################################################
sub load_run{
# read the blast report, collect hits, finds the best hit for every gene
	my($blastReport,$sp1,$sp2)=@_;
	$outF = "$organism/".$sp1."_".$sp2.".txt";
	
	open(IN,"$blastReport")|| warn "no file, $blastReport\n";
	$line = <IN>;#header
	%hits = ();
	GO:while($line = <IN>){
		chomp($line);
		($gene,$hit,$id,$alignmentL,$t,$t,$t,$t,$t,$t,$eval,$score)=split(/\t/,$line);
		# might happened in self comparison
		# when gene eq hit from the same organism- ignored
		if(($gene eq $hit) and ($sp1 eq $sp2)){
			next GO;
		}
		
		if(($eval < 1e-10) and ($score >=100) and ($alignmentL >=100)){# collect only true hits
			
			
			# in rare cases, the alignment length becomes larger than the gene length.
			# in this case we will calculate it relative to the gene length
			if($alignmentL < $genes{$sp1}{$gene}{ORlen}){
				$sharedAA=($id*$alignmentL)/100;
			}else{
				$sharedAA=($id*$genes{$sp1}{$gene}{ORlen})/100;
			}
			$hits{$gene}{$hit}{score}=$hits{$gene}{$hit}{score}+$sharedAA;
			$hits{$gene}{$hit}{alignmentL}=$hits{$gene}{$hit}{alignmentL}+$alignmentL;
	#		if($gene eq 'cand_2.fasta'){
	#				print "FFF $gene,$hit,$genes{$sp1}{$gene}{ORlen},$hits{$gene}{$hit}{score},$hits{$gene}{$hit}{alignmentL}\n";
				#}
		}
		
	}
	close(IN);
	
	#normalize
	foreach $gene (keys %hits){
		foreach $hit (keys %{$hits{$gene}}){	
			# average OR length
			#$aveD = ($genes{$sp1}{$gene}{ORlen}+$genes{$sp2}{$hit}{ORlen})/2;
			$aveD = $genes{$sp1}{$gene}{ORlen};
			# shortest length	
			$shortestD = $genes{$sp1}{$gene}{ORlen};
			if($genes{$sp2}{$hit}{ORlen} < $shortestD){
				$shortestD=$genes{$sp2}{$hit}{ORlen};
			}
	
			# what is the fraction of the gene length that participates in the alignment
			# might get numbers larger than 1=> that's OK!
			#$ORfraction = $hits{$gene}{$hit}{score}/$genes{$sp1}{$gene}{ORlen};
			$ORfraction = $hits{$gene}{$hit}{alignmentL}/$genes{$sp1}{$gene}{ORlen};
			## in rare cases $ORfraction becomes greater than 1.
			## specifically when the aligment has many gaps. 
			## in these cases it will be set to 1
			if($ORfraction > 1.0){
				$ORfraction=1;
			}
			
			$ORfraction_short = $hits{$gene}{$hit}{alignmentL}/$shortestD;
			if($ORfraction_short > 1.0){
				$ORfraction_short=1;
			}
			# do the calculation, save in hash
			$hits{$gene}{$hit}{score_shortest}=($hits{$gene}{$hit}{score}/$shortestD)*100;
			$hits{$gene}{$hit}{score_ave}=($hits{$gene}{$hit}{score}/$aveD)*100;
			$hits{$gene}{$hit}{ORfrac}=$ORfraction;
			$hits{$gene}{$hit}{ORfrac}=$ORfraction;
		#	if($gene eq 'cand_524.fasta'){
		#			print "### $gene,$hit,$hits{$gene}{$hit}{score},$shortestD,$aveD\n";
		#	}

		}
	}
	
	# find best, and save to file
	open(OUT,">$outF")|| warn "can not write to BeH outF\n";
	print OUT "candidate\tBeH(maxAv)\t%id_norm(maxAv)\tAlignFrac(maxAve)\tBeH(maxShort)\t%id_norm(maxShort)\tAlignFrac(maxShort)\n";
	foreach $gene (keys %hits){
	
		$maxAve=0;
		$maxShort=0;
		foreach $hit (keys %{$hits{$gene}}){	
  
			if($hits{$gene}{$hit}{score_ave} > $maxAve){
				$maxAve=$hits{$gene}{$hit}{score_ave};
				$maxAveHit = $hit;
				
				if($gene eq 'cand_2.fasta'){
					print "$gene,$hit,$hits{$gene}{$hit}{score_ave},$maxAve,$maxAveHit\n";
				}
			}
			if($hits{$gene}{$hit}{score_shortest} > $maxShort){
				$maxShort=$hits{$gene}{$hit}{score_shortest};
				$maxShortHit = $hit;
			}
			
		}
		
		$BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_id}=$maxAve;
		$BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_gene}=$maxAveHit;
		$BeH{$sp1}{$sp2}{$gene}{maxAv}{alignFrac}=$hits{$gene}{$maxAveHit}{ORfrac};
		#
		$BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_id}=$maxShort;
		$BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_gene}=$maxShortHit;
		$BeH{$sp1}{$sp2}{$gene}{maxShort}{alignFrac}=$hits{$gene}{$maxShortHit}{ORfrac};
	
		print OUT "$gene\t$maxAveHit\t$maxAve\t$BeH{$sp1}{$sp2}{$gene}{maxAv}{alignFrac}\t$maxShortHit\t$maxShort\t$BeH{$sp1}{$sp2}{$gene}{maxShort}{alignFrac}\n";
	}

	
	close(OUT);
	return();
}
#############################################################################################################
sub save_results{
	my($outF,$refToHash)=@_;
	%hash_to_save = %{$refToHash};
	open(OUT,">$outF")|| warn "can not save results\n";
	print OUT "gene\tMMSstep\tBestMatch\tID\t%ofORLength\tSuggestedClade\n";
	foreach $gene (keys %hash_to_save){
		if($hash_to_save{$gene}{score}==1){
			my $id = sprintf ('%.2f', $hash_to_save{$gene}{id}); 
			my $fractionOfAlignment=$hash_to_save{$gene}{alignFrac}*100;
			$fractionOfAlignment=sprintf ('%.2f', $fractionOfAlignment);
			$hash_to_save{$gene}{clade}=uc($hash_to_save{$gene}{clade});
			print OUT "$gene\t$hash_to_save{$gene}{step}\t$hash_to_save{$gene}{gene}\t$id\t$fractionOfAlignment\t$hash_to_save{$gene}{clade}\n";
		}else{
			print OUT "$gene\tUC\n";
		}
	}
	close(OUT);
}
#############################################################################################################
sub find_self{
	my($sp1,$sp2) = @_;
	foreach $gene (@classificationOrder){
		$alignAA = $BeH{$sp1}{$sp2}{$gene}{maxShort}{alignFrac}*$genes{$sp1}{$gene}{ORlen};
		$BeH_gene=$BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_gene};
		#I am looking for alignment with more than 100 aa, with %id > 60%
		if(($BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_id} >= $beH_cutoff)and ($BeH{$sp1}{$sp2}{$gene}{maxAv}{alignFrac} > $align_frac_cutoff)){
			$self{$gene}{score}=1;# if score ==1, the algorithm will not search any more
			$self{$gene}{step}="SecondBest";
			$self{$gene}{gene}=$BeH_gene;
			$self{$gene}{alignFrac}=$BeH{$sp1}{$sp2}{$gene}{maxAv}{alignFrac};
			$self{$gene}{id}=$BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_id};
		}elsif(($BeH{$sp1}{$sp2}{$gene}{maxShort}{BeH_id} >=60) and ($alignAA >=100)){
			# this is not a mistake. We normalize to the gene length and save in the averaged
			# for future gene symbol assignment
			$self{$gene}{score}=1;# if score ==1, the algorithm will not search any more
			$self{$gene}{step}="NewSubfam_self";
			$self{$gene}{gene}=$BeH_gene;
			$self{$gene}{alignFrac}=$BeH{$sp1}{$sp2}{$gene}{maxAv}{alignFrac};
			$self{$gene}{id}=$BeH{$sp1}{$sp2}{$gene}{maxAv}{BeH_id};
		}
		
	}	
	return();
}
